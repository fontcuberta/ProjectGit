# A Ruby function to say hi and stuff
def greet(name)
  puts "Hi, #{name}!"
end
puts "desserts".reverse