def taste(food)
  if food == "bacon"
    puts "Yummy!!! BACON!!!"
  elsif food == "spinach"
  	puts "EWWW!!! Green stuff"
  else
  	puts "No food for u!"
  end
end

taste "spinach"
taste "bacon"
taste "nofood"